@echo off
rem Direct3D 12 renderer
start "" "%~dp0IslandRoyale.exe" --rendering-method mobile --rendering-driver d3d12
