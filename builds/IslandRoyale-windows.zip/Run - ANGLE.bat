@echo off
rem OpenGL through ANGLE (Direct3D 11)
start "" "%~dp0IslandRoyale.exe" --rendering-driver opengl3_angle
