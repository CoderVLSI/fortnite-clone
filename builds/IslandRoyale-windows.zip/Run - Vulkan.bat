@echo off
rem Vulkan renderer
start "" "%~dp0IslandRoyale.exe" --rendering-method mobile --rendering-driver vulkan
