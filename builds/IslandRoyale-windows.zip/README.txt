ISLAND ROYALE - Windows build (work in progress: stage 3, prompts 1 to 4 of 6 (bots do not build yet))

Run IslandRoyale.exe. No install needed. Click the window to capture the mouse; Esc releases it.

You against 24 bots. Last one standing wins.

  Space            jump from the blimp / jump
  Mouse            look; look down or hold Shift while skydiving to dive
  W A S D          move (the glider opens by itself 42 m above the ground)
  Left mouse       fire / swing the pickaxe / use the held item
  Right mouse      aim
  1-5, wheel       hotbar slots        F   pickaxe
  R                reload              E   open chests and ammo boxes, swap items
  X                drop the held item  M   full map
  G                edit the piece you look at: click or drag tiles, G again confirms, R resets
  Left Ctrl        crouch; while sprinting: slide (faster downhill, ends in a crouch)
  Space at a ledge climb up (0.75 to 2.3 m), also out of the water onto a bank
  Q Z C V          build a wall, floor, stairs, cone (same key again: back to weapons)
  In build mode    left click places (hold to keep placing), right click changes material

Walking over ammo, and over items when you have a free slot, picks them up.
Stay inside the white circle: the purple storm ignores shields.

Hit trees, rocks, fences, crates and buildings with the pickaxe for materials; hit the blue
weak point for double. Pieces cost 10; anything that loses its support collapses.

Known gaps in this build: no sound, bots do not build yet, Mixamo walk/run/idle with code-driven
poses for the rest, and the bots are still weak at finding weapons.

IF YOU SEE "Unable to initialize video driver"
The default renderer needs OpenGL 3.3 or Direct3D 11. Try the launchers in this folder, in this order:
  1. "Run - Direct3D 12.bat"
  2. "Run - Vulkan.bat"
  3. "Run - ANGLE.bat"
If none start, the PC has no working graphics driver (Device Manager shows "Microsoft Basic Display
Adapter"), or it is a remote desktop / virtual machine session. Install the GPU driver from Intel, AMD
or NVIDIA, or run the game on the machine directly.

CHARACTER
The player and bots use the Mixamo Soldier from the three.js examples, with Mixamo animations.
