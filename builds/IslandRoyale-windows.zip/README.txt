ISLAND ROYALE - Windows build (stage 3)

Run IslandRoyale.exe. No install needed. In the lobby press PLAY. Esc pauses (settings: sensitivity, keys,
graphics incl. Show FPS, volume incl. music). LOCKER has 16 outfits, CAREER your level and stats.

50 players: you against 49 bots (easy / normal / sweaty) on an 800 m island with snow in the north and
desert in the south. A 20 s warm-up on the island comes first (no damage). Last one standing wins.

  Space            jump from the blimp / jump
  Mouse            look; look down or hold Shift while skydiving to dive
  E (skydiving)    open the glider early (it opens by itself 42 m above the ground)
  W A S D          move (you run by default; hold right mouse to walk and aim)
  Shift (hold)     tactical sprint: faster, gun lowered (firing or aiming ends it)
  Space            at a low fence or crate while running: hurdle it; at a ledge: climb up
  Left mouse       fire / swing the pickaxe / use the held item
  Right mouse      aim
  1-5, wheel       hotbar slots        F   pickaxe
  R                reload              E   chests, ammo boxes, doors, zip lines, benches, characters
  Tab              inventory           X   drop the held item      M   full map
  B (hold)         emote wheel
  G                edit the piece you look at: click or drag tiles, G again confirms, R resets
  Left Ctrl        crouch; while sprinting: slide
  Space at a ledge climb up (0.75 to 2.3 m), also out of the water
  Q Z C V          build a wall, floor, stairs, cone (same key again: back to weapons)
  In build mode    left click places, right click changes material (it switches by itself
                   to one you have when the current one runs out)

GUNS: pistol, pump and tactical shotgun, SMG, assault, burst and hunting rifle, bolt sniper, rocket
launcher; five rarities. The first shot after a short pause is fully accurate.
HEALS: bandages, med kit, healing drink, small and big shield, hydro juice, mega flask.

BOSSES: Weaver guards Frostpeak, Ravage guards Sandbar Depot, Tinker guards Gearworks Yard (skulls on
the map). Beat one for its MYTHIC weapons, gold and a KEYCARD; the keycard opens the vault next to the
lair (E at the door), which holds three golden chests of top loot.
  Weaver's Web Shooters   hold fire on a surface to swing on a web, let go to fly
  Ravage's Grasp          yank an enemy in and slam them, or pull yourself to a wall
  Tinker's Charge Shotgun hold fire to charge, release to shoot (full charge: 2x damage)
  Tinker's Shockwave      an orb that launches players (no fall damage) and wrecks builds
The crosshair turns red on an enemy's head; headshots show yellow damage numbers.

GOLD BARS are the 4th material: from chests, supply drops, floor piles and eliminations.
UPGRADE BENCHES in the towns raise the held weapon a rarity for 100 / 150 / 200 / 250 gold.
CHARACTERS FOR HIRE stand at points of interest: walk up, press E, and hire them for gold. They
follow you and fight beside you.

Zip lines (E at a pole or tower deck), launch pads, and purple rifts (walk through to skydive again).
Supply drops fall during the match and hold better loot. Stay inside the white circle.

Everything can be farmed with the pickaxe, houses included; hit the blue weak point for double. A
building that loses its support collapses and the loot inside falls to the ground.

IF YOU SEE "Unable to initialize video driver"
The default renderer needs OpenGL 3.3 or Direct3D 11. Try the launchers in this folder, in this order:
  1. "Run - Direct3D 12.bat"
  2. "Run - Vulkan.bat"
  3. "Run - ANGLE.bat"
If none start, install the GPU driver from Intel, AMD or NVIDIA, or run the game on the machine
directly (not over remote desktop or in a virtual machine).

CHARACTERS
The player and bots use the Mixamo Soldier and X Bot with Mixamo animations.
