ISLAND ROYALE - Windows build (work in progress: stage 3, prompt 1 "battle royale core")

Run IslandRoyale.exe. No install needed. Click the window to capture the mouse; Esc releases it.

You against 24 bots. Last one standing wins.

  Space            jump from the blimp / jump
  Mouse            look; look down or hold Shift while skydiving to dive
  W A S D          move (the glider opens by itself 42 m above the ground)
  Left mouse       fire / swing the pickaxe / use the held item
  Right mouse      aim
  1-5, wheel       hotbar slots        F   pickaxe
  R                reload              E   open chests and ammo boxes, swap items
  G                drop the held item  M   full map

Walking over ammo, and over items when you have a free slot, picks them up.
Stay inside the white circle: the purple storm ignores shields.

Known gaps in this build: no sound, no building or harvesting yet, simple code-driven character
animation, and the bots are still weak at finding weapons.
